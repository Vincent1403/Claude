Scryns lamp, 3D model

scryns-lamp.glb: one file with the gradient inside. Import into After Effects (2024 or later) with File > Import, or into Blender / Cinema 4D.
scryns-lamp.obj + .mtl + scryns-lamp-gradient.png: the same model for programs without glTF.

The gradient is a texture; each face samples it at a fixed point, so the look matches the page. The material is set to unlit/emissive where the program supports it; if it looks dark, turn off lighting for the layer or raise its emissive or ambient value.
Units: about 864 wide. Y is up. 64 triangles. Gradient: board.
